#include<stdio.h>
#include<string.h>
#include<stdlib.h>
extern char str[100],New[100],stack[100];
extern int i,j,top,count;
int check_priority(char ch);
void push(char ch);
char pop();
