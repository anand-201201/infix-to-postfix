#include"header.h"
int main()
{
	printf("enter the statement:");
	fgets(str,100,stdin);
	if(str[strlen(str)-1]=='\n')
		str[strlen(str)-1]='\0';
	for(i=0;str[i];i++)
	{
		if(((str[i]>='A') && (str[i]<='Z'))||((str[i]>='a') && (str[i]<='z')))
		{
			New[j++]=str[i];
		}
		else
		{
			if((str[i]=='(')||(str[i]=='[')||(str[i]=='{'))
			{
				push(str[i]);
				count++;
			}
			else if(str[i]==')')
			{
				while(pop()!='(');
				if(stack[top+1]!='(')
				{
					printf("invalid expression\n");
					exit(0);
				}
				count--;
			}
			else if(str[i]==']')
			{
				while(pop()!='[');
				if(stack[top+1]!='[')
				{
					printf("invalid expression\n");
					exit(0);
				}
				count--;
				
			}
			else if(str[i]=='}')
			{
				while(pop()!='{')
				if(stack[top+1]!='{')
				{
					printf("invalid expression\n");
			                exit(0);
				}
				count--;
			}
			else
			{
				if(stack[top]=='('|| stack[top]=='[' || stack[top]=='{')
				{
					push(str[i]);
				}
				else if(check_priority(stack[top])>check_priority(str[i]))
				{
					while((stack[top]!='(')&&(stack[top]!='[')&&(stack[top])!='{')
					{
						pop();
						if(top<0)
							break;
					}
					push(str[i]);
				}
				else if(check_priority(stack[top])==check_priority(str[i]))
				{
					pop();
					push(str[i]);
				}
				else
				{
					push(str[i]);
				}
			}
		}
	}
	while(top>=0)
		pop();
	puts(New);
}
