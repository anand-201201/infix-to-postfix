#include"header.h"
void push(char ch)
{
	stack[++top]=ch;
}
char pop()
{
	char temp;
	temp=stack[top];
	if((stack[top]!='(')&&(stack[top]!='[')&&(stack[top]!='{'))
		New[j++]=temp;
	top--;
	return temp;
}
int check_priority(char ch)
{
	if(ch=='^')
		return 3;
	else if(ch=='*'||ch=='/'||ch=='%')
	        return 2;
	else if(ch=='+'||ch=='-')
		return 1;
	else
	return 0;
}
